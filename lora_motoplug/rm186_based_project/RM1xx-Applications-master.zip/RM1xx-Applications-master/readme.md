# RM1xx-Applications

This repository contains example smartBASIC applications for the RM186 and RM191 devices. 

Some of these applications require the RM1xx-defs.h file located in the firmware release package. Please be sure to use the RM1xx.h file associated with the firmware loaded on the module. The firmware version can be checked at the smartBASIC command prompt with the "ATI 3" command.
